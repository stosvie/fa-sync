The easiest to use, most complete, and most actively developed Python interface to the Flickr API.It includes support for authorized and non-authorized access, uploading and replacing photos, and all Flickr API functions.


